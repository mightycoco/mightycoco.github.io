# Firmware for Alxing

Currently Windows only.

Download all files to a folder. Connect Alxing via an USB-C cacble to your computer and execute upload.exe

The Module should show up as a Serial COM device:

```
Programming device
1: "Communications Port (COM1)"
2: "USB Serial Device (COM5)"
Select device:
```

If you have multiple "USB Serial Device" devices, you should unplug all USB Serial Devices and try again. After resetting the CPU and putting it into bootloader mode, Alxing may get a new COM-Port. The upload script expects after resetting the first USB Serial Device to be the module.

This example Alxing is on COM5. Enter 2 and hit "Enter"
The output should show your device resetting and uploading the code.
Alxing will restart and should show a new Build number in the startup screen.
